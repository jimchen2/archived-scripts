const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  setStoreValue: (key, value) => ipcRenderer.invoke('set-store-value', key, value),
  getStoreValue: (key) => ipcRenderer.invoke('get-store-value', key),
  onGoBack: (callback) => ipcRenderer.on('go-back', callback),
  onGoForward: (callback) => ipcRenderer.on('go-forward', callback),
  onRefreshPage: (callback) => ipcRenderer.on('refresh-page', callback),
  onNextApp: (callback) => ipcRenderer.on('next-app', callback),
  onPrevApp: (callback) => ipcRenderer.on('prev-app', callback),
  onToggleSidebar: (callback) => ipcRenderer.on('toggle-sidebar', callback),
  getWebAppsJson: () => ipcRenderer.invoke('get-webapps-json'),
  saveWebAppsJson: (newData) => ipcRenderer.invoke('save-webapps-json', newData)
});