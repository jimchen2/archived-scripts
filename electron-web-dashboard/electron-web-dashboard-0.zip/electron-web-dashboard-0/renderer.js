const appList = document.getElementById('app-list');
const webview = document.getElementById('webview');
const sidebar = document.getElementById('sidebar');
let allApps = [];
let currentAppIndex = -1;

window.electronAPI.getWebAppsJson()
  .then(data => {
    if (data) {
      const webApps = data.webApps;
      
      webApps.forEach(category => {
        const categoryHeader = document.createElement('h3');
        categoryHeader.className = 'text-lg font-normal mt-4 mb-2 text-gray-700';
        categoryHeader.textContent = category.category;
        appList.appendChild(categoryHeader);

        const categoryList = document.createElement('ul');
        categoryList.className = 'space-y-2';
        category.apps.forEach(app => {
          allApps.push(app);
          const li = document.createElement('li');
          const button = document.createElement('button');
          button.className = 'w-full py-2 px-4 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50 transition duration-200 shadow-sm';
          button.textContent = app.name;
          button.addEventListener('click', () => loadWebApp(app.url));
          li.appendChild(button);
          categoryList.appendChild(li);
        });
        appList.appendChild(categoryList);
      });
    }
  })
  .catch(error => console.error('Error loading web apps data:', error));

function loadWebApp(url) {
  webview.src = url;
  currentAppIndex = allApps.findIndex(app => app.url === url);
}

webview.addEventListener('did-finish-load', async () => {
  const currentURL = webview.getURL();
  await window.electronAPI.setStoreValue('lastOpenedURL', currentURL);
});

window.electronAPI.getStoreValue('lastOpenedURL').then(lastOpenedURL => {
  if (lastOpenedURL) {
    loadWebApp(lastOpenedURL);
  }
});

window.electronAPI.onGoBack(() => {
  if (webview.canGoBack()) {
    webview.goBack();
  }
});

window.electronAPI.onGoForward(() => {
  if (webview.canGoForward()) {
    webview.goForward();
  }
});

window.electronAPI.onRefreshPage(() => {
  webview.reload();
});

window.electronAPI.onNextApp(() => {
  if (allApps.length > 0) {
    currentAppIndex = (currentAppIndex + 1) % allApps.length;
    loadWebApp(allApps[currentAppIndex].url);
  }
});

window.electronAPI.onPrevApp(() => {
  if (allApps.length > 0) {
    currentAppIndex = (currentAppIndex - 1 + allApps.length) % allApps.length;
    loadWebApp(allApps[currentAppIndex].url);
  }
});

window.electronAPI.onToggleSidebar(() => {
  if (sidebar.style.display === 'none') {
    sidebar.style.display = 'block';
  } else {
    sidebar.style.display = 'none';
  }
});