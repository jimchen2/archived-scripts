Edit
`~/.config/electron-web-dashboard-nodejs/webApps.json`