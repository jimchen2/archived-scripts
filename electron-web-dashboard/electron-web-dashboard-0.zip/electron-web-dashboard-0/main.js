const { app, BrowserWindow, ipcMain, globalShortcut } = require('electron');
const path = require('path');
const fs = require('fs');
const envPaths = require('env-paths');

let store;
let mainWindow;
let webAppsJsonPath;

async function initializeStore() {
  const Store = await import('electron-store');
  store = new Store.default();

  const paths = envPaths('electron-web-dashboard');
  const configDirPath = paths.config;
  webAppsJsonPath = path.join(configDirPath, 'webApps.json');
  console.log('webAppsJsonPath:', webAppsJsonPath);

  fs.mkdirSync(configDirPath, { recursive: true });

  if (!fs.existsSync(webAppsJsonPath)) {
    const defaultContent = {
      webApps: [
        {
          category: "Default",
          apps: [
            { name: "Example App", url: "https://example.com" }
          ]
        }
      ]
    };
    fs.writeFileSync(webAppsJsonPath, JSON.stringify(defaultContent, null, 2));
    console.log('Default webApps.json file created');
  }
}

async function createWindow() {
  await initializeStore();

  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webviewTag: true,
      preload: path.join(__dirname, 'preload.js')
    },
  });

  mainWindow.webContents.setUserAgent('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36');

  mainWindow.loadFile('index.html');

  globalShortcut.register('Alt+Left', () => {
    mainWindow.webContents.send('go-back');
  });

  globalShortcut.register('Alt+Right', () => {
    mainWindow.webContents.send('go-forward');
  });

  globalShortcut.register('CommandOrControl+R', () => {
    mainWindow.webContents.send('refresh-page');
  });

  globalShortcut.register('CommandOrControl+Tab', () => {
    mainWindow.webContents.send('next-app');
  });

  globalShortcut.register('CommandOrControl+Shift+Tab', () => {
    mainWindow.webContents.send('prev-app');
  });

  globalShortcut.register('CommandOrControl+B', () => {
    mainWindow.webContents.send('toggle-sidebar');
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    globalShortcut.unregisterAll();
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

ipcMain.handle('get-store-value', (event, key) => {
  return store.get(key);
});

ipcMain.handle('set-store-value', (event, key, value) => {
  store.set(key, value);
});

ipcMain.handle('get-webapps-json', async () => {
  try {
    const data = await fs.promises.readFile(webAppsJsonPath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading webApps.json:', error);
    return null;
  }
});

ipcMain.handle('save-webapps-json', async (event, newData) => {
  try {
    await fs.promises.writeFile(webAppsJsonPath, JSON.stringify(newData, null, 2));
    return true;
  } catch (error) {
    console.error('Error writing webApps.json:', error);
    return false;
  }
});