https://openrouter.ai/credits

"Print"