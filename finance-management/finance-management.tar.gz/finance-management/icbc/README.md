I have one bank card. The bank card credential is saved on AWS Secrets.

Go to download the apk `https://mywap2.icbc.com.cn/ICBCWAPBank/servlet/PortalInject?inject=invest`

Log in to the app, then 

首页 ->账户 -> 更多 -> 历史明细打印 

Then manually type everything