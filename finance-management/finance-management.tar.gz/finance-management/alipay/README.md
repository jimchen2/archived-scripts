Export: go to web: https://alipay.com

https://my.alipay.com/portal/i.htm
https://help.alipay.com/hall/index.htm
https://cshall.alipay.com/lab/selfHelp.htm
https://consumeprod.alipay.com/record/standard.htm

“服务大厅”
“自助服务”
"交易记录"
“下载查询结果”

![alt text](image.png)

```
iconv -f GB2312 -t UTF-8 output.csv > alipay_record_utf8.csv
```

*For csv please delete the first four lines, and the last 7 lines*