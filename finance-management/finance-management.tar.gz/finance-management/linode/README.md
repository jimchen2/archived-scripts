https://cloud.linode.com/account/billing
Download the invoice

Best practices

1. Strong root password and disable password ssh
2. For database either user hard password or disable access for IP ranges
