I only use R2 right now.

## 20240905

I configured Cloudflare R2 to be not instant retrieval and messed everything up. I spent 80 dollars a month retrieving data.
