Google Takeout: https://takeout.google.com/

Google Pay: Google Transactions