I am turning away from AWS.

### Purchasing a Savings Plan 2024.8.5

I purchased a savings plan for EC2 instances.

Due to too much cost mismanagement over the last 2 months I am playing conservative for now.

```
aws ce get-cost-and-usage \
    --time-period Start=2024-05-01,End=2024-06-01 \
    --granularity MONTHLY \
    --metrics "UnblendedCost" \
    --group-by Type=DIMENSION,Key=SERVICE \
    --output table > output
```

### Incident 9.15

I forgot to stop a notebook in Sagemaker on July and incurred about 10 dollars charge.

### Incident 8.18

Also seems like no one is safe from billing on AWS

https://news.ycombinator.com/item?id=40203126

https://old.reddit.com/r/devops/comments/1cgklx9/an_article_citing_important_s3_bucket_pricing/

AWS S3 is still widely used, the best I can do is to pray and hope I don't get 3 extra zeros on my bills.

### Incident 2024.7.17

I didn't shut down my V100 GPU after using it, costing around 70 dollars.

### Incident 2024.6.12

I attempted to make my blog accessible in Chinese by calling the AWS translation API. The translation API was very good, but I kept batch processing my entire blog each time, thinking it was cheap. It turns out my blog has around 100,000 words, and I processed it about 10 times due to minor formatting issues in Chinese. This resulted in a 100 dollars charge to my account.

### Incident 2024.6.4

On June 4, I attempted to advance pay AWS. However, there was a wire transfer fee of 25 dollars. I deposited 50 dollars into my AWS account.
