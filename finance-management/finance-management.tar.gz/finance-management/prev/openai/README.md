Go to https://platform.openai.com/settings/organization/billing/history
Then ctrl+p
