https://cloud.vast.ai/billing/
Select date then export csv 

Type:All, not only payment, both payment and charge
