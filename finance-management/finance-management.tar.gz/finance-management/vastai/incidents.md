### Incident 2024.8.30

I fell asleep while playing with 2x A100 GPU  in VastAI, losing 10 dollars.
