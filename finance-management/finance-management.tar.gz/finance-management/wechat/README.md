Export WeChat: Service Notification -> Click on the "微信支付凭证, not the top but in the middle -> Click All transactions -> Click FAQ -> Click Download

Wechat is connected to ICBC Bank card.
