import axios from 'axios';
import Parser from 'rss-parser';
import Feed from '../models/Feed';
import Article from '../models/Article';

const parser = new Parser();

export async function fetchAndUpdateFeeds() {
  const feeds = await Feed.find({});

  for (const feed of feeds) {
    try {
      const response = await axios.get(feed.url);
      const parsedFeed = await parser.parseString(response.data);

      for (const item of parsedFeed.items) {
        const existingArticle = await Article.findOne({ link: item.link });

        if (!existingArticle) {
          await Article.create({
            feedId: feed._id,
            title: item.title,
            link: item.link,
            description: item.content,
            pubDate: item.pubDate ? new Date(item.pubDate) : new Date(),
            categories: item.categories || [],
          });
        }
      }

      await Feed.findByIdAndUpdate(feed._id, { lastUpdated: new Date() });
    } catch (error) {
      console.error(`Error fetching feed ${feed.url}:`, error);
    }
  }
}