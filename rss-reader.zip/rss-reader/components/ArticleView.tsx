import axios from 'axios';

export default function ArticleView({ article, onArticleRead }) {
  if (!article) return <div className="flex-1 p-4">Select an article to read</div>;

  const markAsRead = async () => {
    if (!article.isRead) {
      const updatedArticle = await axios.patch(`/api/articles?id=${article._id}`, { isRead: true });
      onArticleRead(updatedArticle.data);
    }
  };

  return (
    <div className="flex-1 p-4 overflow-y-auto">
      <h2 className="text-2xl font-bold mb-4">{article.title}</h2>
      <div
        className="prose"
        dangerouslySetInnerHTML={{ __html: article.description }}
      />
      {!article.isRead && (
        <button
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
          onClick={markAsRead}
        >
          Mark as Read
        </button>
      )}
    </div>
  );
}