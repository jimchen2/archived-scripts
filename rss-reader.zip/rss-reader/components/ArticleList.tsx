import { useState, useEffect } from 'react';
import axios from 'axios';

export default function ArticleList({ feedId, isUnreadSelected, onSelectArticle }) {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    fetchArticles();
  }, [feedId, isUnreadSelected]);

  const fetchArticles = async () => {
    let url = '/api/articles?';
    if (feedId) {
      url += `feedId=${feedId}`;
    } else if (isUnreadSelected) {
      url += 'isRead=false';
    }
    const response = await axios.get(url);
    setArticles(response.data);
  };

  return (
    <div className="w-1/3 bg-white border-r overflow-y-auto">
      <h2 className="text-xl font-bold p-4">
        {isUnreadSelected ? 'Unread Articles' : 'Articles'}
      </h2>
      <ul>
        {articles.map((article) => (
          <li
            key={article._id}
            className={`px-4 py-2 hover:bg-gray-100 cursor-pointer ${
              article.isRead ? 'text-gray-500' : 'font-bold'
            }`}
            onClick={() => onSelectArticle(article)}
          >
            {article.title}
          </li>
        ))}
      </ul>
    </div>
  );
}