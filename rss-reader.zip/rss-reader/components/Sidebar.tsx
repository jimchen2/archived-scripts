import { useState, useEffect } from 'react';
import axios from 'axios';

export default function Sidebar({ onSelectFeed, onSelectUnread }) {
  const [feeds, setFeeds] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [newFeedUrl, setNewFeedUrl] = useState('');
  const [isFetching, setIsFetching] = useState(false);

  useEffect(() => {
    fetchFeeds();
    fetchUnreadCount();
  }, []);

  const fetchFeeds = async () => {
    const response = await axios.get('/api/feeds');
    setFeeds(response.data);
  };

  const fetchUnreadCount = async () => {
    const response = await axios.get('/api/articles?isRead=false');
    setUnreadCount(response.data.length);
  };

  const handleAddFeed = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/feeds', { url: newFeedUrl });
      setFeeds([...feeds, response.data]);
      setNewFeedUrl('');
    } catch (error) {
      console.error('Error adding feed:', error);
      // You might want to show an error message to the user here
    }
  };

  const handleFetchRss = async () => {
    setIsFetching(true);
    try {
      const response = await axios.post('/api/fetchRss');
      alert(response.data.message);
      fetchFeeds(); // Refresh the feed list
      fetchUnreadCount(); // Refresh the unread count
    } catch (error) {
      console.error('Error fetching RSS:', error);
      alert('Error fetching RSS feeds');
    }
    setIsFetching(false);
  };

  return (
    <div className="w-64 bg-white border-r flex flex-col">
      <h2 className="text-xl font-bold p-4">Feeds</h2>
      <button
        onClick={handleFetchRss}
        disabled={isFetching}
        className="mx-4 mb-4 px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:bg-green-300"
      >
        {isFetching ? 'Fetching...' : 'Fetch RSS'}
      </button>
      <ul className="flex-grow overflow-y-auto">
        <li
          className="px-4 py-2 hover:bg-gray-100 cursor-pointer font-bold"
          onClick={() => onSelectUnread()}
        >
          Unread ({unreadCount})
        </li>
        {feeds.map((feed) => (
          <li
            key={feed._id}
            className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
            onClick={() => onSelectFeed(feed._id)}
          >
            {feed.title}
          </li>
        ))}
      </ul>
      <form onSubmit={handleAddFeed} className="p-4 border-t">
        <input
          type="url"
          value={newFeedUrl}
          onChange={(e) => setNewFeedUrl(e.target.value)}
          placeholder="Enter RSS feed URL"
          className="w-full px-2 py-1 border rounded"
          required
        />
        <button
          type="submit"
          className="w-full mt-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Add Feed
        </button>
      </form>
    </div>
  );
}