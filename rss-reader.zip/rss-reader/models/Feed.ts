import mongoose from 'mongoose';

const FeedSchema = new mongoose.Schema({
  url: { type: String, required: true, unique: true },
  title: { type: String, required: true },
  description: { type: String },
  categories: [{ type: String }],
});

export default mongoose.models.Feed || mongoose.model('Feed', FeedSchema);