import mongoose from 'mongoose';

const ArticleSchema = new mongoose.Schema({
  feedId: { type: mongoose.Schema.Types.ObjectId, ref: 'Feed', required: true },
  title: { type: String, required: true },
  link: { type: String, unique: true, sparse: true },
  description: { type: String },
  pubDate: { type: Date },
  isRead: { type: Boolean, default: false },
  categories: [{ type: String }],
});

export default mongoose.models.Article || mongoose.model('Article', ArticleSchema);