import { NextApiRequest, NextApiResponse } from 'next';
import dbConnect from '../../lib/dbConnect';
import Feed from '../../models/Feed';
import Parser from 'rss-parser';

const parser = new Parser();

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  await dbConnect();

  if (req.method === 'GET') {
    const feeds = await Feed.find({});
    res.status(200).json(feeds);
  } else if (req.method === 'POST') {
    try {
      const { url } = req.body;
      const feedData = await parser.parseURL(url);
      
      const feed = await Feed.create({
        url,
        title: feedData.title || 'Untitled Feed',
        description: feedData.description || '',
      });
      
      res.status(201).json(feed);
    } catch (error) {
      res.status(400).json({ error: 'Invalid feed URL' });
    }
  } else {
    res.status(405).end();
  }
}