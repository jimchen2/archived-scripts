import { NextApiRequest, NextApiResponse } from 'next';
import dbConnect from '../../lib/dbConnect';
import Article from '../../models/Article';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  await dbConnect();

  if (req.method === 'GET') {
    const { feedId, isRead } = req.query;
    const query: any = {};
    if (feedId) query.feedId = feedId;
    if (isRead !== undefined) query.isRead = isRead === 'true';
    const articles = await Article.find(query).sort({ pubDate: -1 });
    res.status(200).json(articles);
  } else if (req.method === 'PATCH') {
    const { id } = req.query;
    const article = await Article.findByIdAndUpdate(id, req.body, { new: true });
    res.status(200).json(article);
  } else {
    res.status(405).end();
  }
}