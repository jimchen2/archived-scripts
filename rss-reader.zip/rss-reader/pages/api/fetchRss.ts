import { NextApiRequest, NextApiResponse } from 'next';
import dbConnect from '../../lib/dbConnect';
import Feed from '../../models/Feed';
import Article from '../../models/Article';
import Parser from 'rss-parser';

const parser = new Parser({
  defaultRSS: 2.0,
  customFields: {
    item: [
      ['media:content', 'media:content', {keepArray: true}],
      ['content:encoded', 'contentEncoded'],
    ],
  },
});

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  await dbConnect();

  if (req.method === 'POST') {
    try {
      const feeds = await Feed.find({});
      let newArticlesCount = 0;

      for (const feed of feeds) {
        try {
          const feedData = await parser.parseURL(feed.url);
          
          for (const item of feedData.items) {
            const articleData = {
              feedId: feed._id,
              title: item.title || 'Untitled',
              link: item.link || item.guid || '',
              description: item.content || item.contentEncoded || item.description || '',
              pubDate: item.pubDate ? new Date(item.pubDate) : new Date(),
              categories: item.categories || [],
            };

            // If there's no link, try to extract it from the content
            if (!articleData.link && articleData.description) {
              const linkMatch = articleData.description.match(/<a\s+(?:[^>]*?\s+)?href="([^"]*)"/)
              if (linkMatch) {
                articleData.link = linkMatch[1];
              }
            }

            // If still no link, use a placeholder
            if (!articleData.link) {
              articleData.link = `no-link-${Date.now()}-${Math.random()}`;
            }

            // Check if the article already exists in the database
            const existingArticle = await Article.findOne({ link: articleData.link });
            if (!existingArticle) {
              await Article.create(articleData);
              newArticlesCount++;
            }
          }
        } catch (feedError) {
          console.error(`Error processing feed ${feed.url}:`, feedError);
        }
      }

      res.status(200).json({ message: `Fetched RSS feeds. ${newArticlesCount} new articles added.` });
    } catch (error) {
      console.error('Error fetching RSS feeds:', error);
      res.status(500).json({ error: 'Error fetching RSS feeds' });
    }
  } else {
    res.status(405).end();
  }
}