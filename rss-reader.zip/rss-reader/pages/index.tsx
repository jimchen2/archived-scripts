import { useState, useEffect } from 'react';
import Head from 'next/head';
import axios from 'axios';
import Sidebar from '../components/Sidebar';
import ArticleList from '../components/ArticleList';
import ArticleView from '../components/ArticleView';

export default function Home() {
  const [selectedFeed, setSelectedFeed] = useState(null);
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [isUnreadSelected, setIsUnreadSelected] = useState(false);

  useEffect(() => {
    const fetchInterval = setInterval(() => {
      fetchRss();
    }, 30 * 60 * 1000); // Fetch every 30 minutes

    return () => clearInterval(fetchInterval);
  }, []);

  const fetchRss = async () => {
    try {
      await axios.post('/api/fetchRss');
      console.log('RSS feeds fetched');
    } catch (error) {
      console.error('Error fetching RSS feeds:', error);
    }
  };

  const handleSelectFeed = (feedId) => {
    setSelectedFeed(feedId);
    setIsUnreadSelected(false);
  };

  const handleSelectUnread = () => {
    setSelectedFeed(null);
    setIsUnreadSelected(true);
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <Head>
        <title>RSS Reader</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Sidebar onSelectFeed={handleSelectFeed} onSelectUnread={handleSelectUnread} />

      <main className="flex-1 flex">
        <ArticleList
          feedId={selectedFeed}
          isUnreadSelected={isUnreadSelected}
          onSelectArticle={setSelectedArticle}
        />
        <ArticleView article={selectedArticle} />
      </main>
    </div>
  );
}